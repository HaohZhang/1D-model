#!/bin/sh
#___INFO__MARK_BEGIN__
# Welcome to use  EasyCluster V1.6 All Rights Reserved.
#
#___INFO__MARK_END__
#
#$ -S /bin/sh
#$ -N test1
#$ -j y
#$ -o ./
#$ -e ./
#$ -cwd
#$ -pe mpi 1
#$ -q normal.q
#source ~/.bash_profile
source ~/.bashrc
hash -r
export path=$TMPDIR:$path

export OMP_NUM_THREADS=1
/usr/local/mpich3.3.2/bin/mpiexec -n $NSLOTS -f $TMPDIR/machines ./mitgcmuv 
